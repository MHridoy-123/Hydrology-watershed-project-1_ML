# Raw data

Place the supplied file `dairy_watershed_monthly_loads.csv` in this directory.

The analysis expects monthly records with the following required columns:

- `Date`
- `Station`
- `Streamflow`
- `TSS`
- `NH3_NH4_N`
- `NO3_NO2_N`
- `PO4_P`
- `Cl`
- `DOC`
- `TDN`
- `P_total`

Before making the repository public, verify that the original dataset license permits redistribution. If redistribution is not permitted, replace the CSV with its DOI or official repository link.
