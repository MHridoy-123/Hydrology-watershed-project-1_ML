# Event-driven contaminant export and watershed predictability

Reproducible code and outputs for the study:

> **Event-driven export reveals a watershed vulnerability-predictability gap**

## Scope

The workflow analyzes monthly streamflow and constituent loads from four agricultural watershed stations (2014-2020). It evaluates seasonality, flow-load elasticity, high-flow enrichment, export inequality, deseasonalized trends, false-discovery-rate correction, and rolling-origin streamflow prediction.

## Repository structure

```text
data/raw/                    Input CSV and data-access note
src/run_analysis.py          Portable executed workflow
results/figures/             Publication figures embedded in the manuscript
results/generated_figures/   Figures generated when the script is rerun
results/generated_tables/    Machine-readable outputs generated on rerun
requirements.txt             Python dependencies
CITATION.cff                 Citation metadata
LICENSE                      Code license
```

## Run

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/run_analysis.py
```

Place the supplied CSV at:

```text
data/raw/dairy_watershed_monthly_loads.csv
```

## Interpretation boundary

This repository does not contain a SWAT simulation. The dataset lacks meteorological forcing, DEM, soil, land use, management schedules, watershed spatial layers, and an executable SWAT project. The workflow supports observed watershed hydrology, contaminant-export analysis, trends, and machine-learning prediction.

## Data redistribution

Confirm the original dataset licence before publishing the raw CSV. If redistribution is not permitted, remove the CSV and provide the official DOI or repository link instead.
