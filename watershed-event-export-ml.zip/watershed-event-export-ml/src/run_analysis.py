"""Reproducible watershed event-export and streamflow prediction workflow."""
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import kendalltau, theilslopes, linregress
from statsmodels.stats.multitest import multipletests
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
warnings.filterwarnings("ignore")
SEED=42
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data/raw/dairy_watershed_monthly_loads.csv"
OUT=ROOT/"results"
FIG=OUT/"generated_figures"
TAB=OUT/"generated_tables"
FIG.mkdir(parents=True,exist_ok=True); TAB.mkdir(parents=True,exist_ok=True)
if not DATA.exists(): raise FileNotFoundError(f"Place the raw CSV at {DATA}")
df=pd.read_csv(DATA); df["Date"]=pd.to_datetime(df["Date"])
df=df.sort_values(["Station","Date"]).reset_index(drop=True)
df["Year"]=df.Date.dt.year; df["Month"]=df.Date.dt.month
stations=sorted(df.Station.unique())
variables=["Streamflow","TSS","NH3_NH4_N","NO3_NO2_N","PO4_P","Cl","DOC","TDN","P_total"]
constituents=["TSS","NH3_NH4_N","NO3_NO2_N","PO4_P","Cl","P_total"]
# Data audit
a=[]
for s,g in df.groupby("Station"):
    for v in variables:
        x=g[v]
        a.append([s,v,len(x),x.notna().sum(),100*x.isna().mean(),100*(x==0).mean(),x.mean(),x.median(),x.std(),x.min(),x.max()])
audit=pd.DataFrame(a,columns=["Station","Variable","N","Valid_N","Missing_pct","Zero_pct","Mean","Median","SD","Min","Max"])
audit.to_csv(TAB/"data_audit.csv",index=False)
# Flow-load elasticity
elastic=[]
for s,g in df.groupby("Station"):
    for v in constituents:
        z=g[["Streamflow",v]].dropna(); z=z[(z.Streamflow>0)&(z[v]>0)]
        r=linregress(np.log10(z.Streamflow),np.log10(z[v])); ci=1.96*r.stderr
        elastic.append([s,v,len(z),r.slope,r.slope-ci,r.slope+ci,r.rvalue**2,r.pvalue])
elastic=pd.DataFrame(elastic,columns=["Station","Constituent","N","Elasticity","CI_low","CI_high","R2","P_value"])
elastic.to_csv(TAB/"flow_load_elasticity.csv",index=False)
# Deseasonalized trends and FDR
trend=[]
for s,g in df.groupby("Station"):
    for v in variables:
        z=g[["Month",v]].dropna().copy()
        z["Anomaly"]=z[v]-z.groupby("Month")[v].transform("median")
        t=np.arange(len(z)); tau,p=kendalltau(t,z.Anomaly); slope,inter,lo,hi=theilslopes(z.Anomaly,t,.95)
        trend.append([s,v,len(z),tau,p,slope,lo,hi])
trend=pd.DataFrame(trend,columns=["Station","Variable","N","Tau","P_raw","Sen_slope_month","CI_low","CI_high"])
trend["P_FDR"]=multipletests(trend.P_raw,method="fdr_bh")[1]; trend["Significant_FDR"]=trend.P_FDR<.05
trend.to_csv(TAB/"trends_fdr.csv",index=False)
# High-flow export and Gini
def gini(x):
    x=np.sort(np.asarray(x,float)); x=x[np.isfinite(x)&(x>=0)]
    if len(x)==0 or x.sum()==0:return np.nan
    n=len(x); return 2*np.sum(np.arange(1,n+1)*x)/(n*x.sum())-(n+1)/n
extreme=[]
for s,g in df.groupby("Station"):
    q90=g.Streamflow.quantile(.9); high=g.Streamflow>=q90
    for v in constituents:
        x=g[v].fillna(0).clip(lower=0); share=x[high].sum()/x.sum() if x.sum() else np.nan
        extreme.append([s,v,q90,high.sum(),share,share/.1,gini(x)])
extreme=pd.DataFrame(extreme,columns=["Station","Constituent","Q90","High_flow_months","Top10_load_share","Enrichment_factor","Gini"])
extreme.to_csv(TAB/"highflow_export.csv",index=False)
# Rolling-origin streamflow prediction
pred=[]; metrics=[]
for s,g in df.groupby("Station"):
    g=g.copy().sort_values("Date")
    for lag in [1,2,3,6,12]:g[f"lag{lag}"]=g.Streamflow.shift(lag)
    g["roll3"]=g.Streamflow.shift(1).rolling(3).mean();g["roll6"]=g.Streamflow.shift(1).rolling(6).mean()
    g["sinM"]=np.sin(2*np.pi*g.Month/12);g["cosM"]=np.cos(2*np.pi*g.Month/12)
    feats=[f"lag{x}" for x in [1,2,3,6,12]]+["roll3","roll6","sinM","cosM"]
    z=g.dropna(subset=feats+["Streamflow"])
    for yr in [2017,2018,2019,2020]:
        tr=z[z.Year<yr];te=z[z.Year==yr]
        if len(tr)<24 or len(te)==0:continue
        models={"Persistence":None,"SeasonalNaive":"seasonal","RandomForest":RandomForestRegressor(n_estimators=800,min_samples_leaf=3,max_features=.8,random_state=SEED),"ExtraTrees":ExtraTreesRegressor(n_estimators=800,min_samples_leaf=3,max_features=.8,random_state=SEED),"HGBR":HistGradientBoostingRegressor(max_iter=300,l2_regularization=1,random_state=SEED)}
        for name,model in models.items():
            if model is None:yhat=te.lag1.to_numpy()
            elif model=="seasonal":yhat=te.lag12.to_numpy()
            else:model.fit(tr[feats],tr.Streamflow);yhat=np.clip(model.predict(te[feats]),0,None)
            y=te.Streamflow.to_numpy(); nse=1-np.sum((y-yhat)**2)/np.sum((y-y.mean())**2)
            r=np.corrcoef(y,yhat)[0,1] if np.std(yhat)>0 else np.nan
            alpha=np.std(yhat,ddof=1)/np.std(y,ddof=1); beta=np.mean(yhat)/np.mean(y)
            kge=1-np.sqrt((r-1)**2+(alpha-1)**2+(beta-1)**2) if np.isfinite(r) else np.nan
            metrics.append([s,yr,name,len(tr),len(te),nse,kge,mean_squared_error(y,yhat)**.5,mean_absolute_error(y,yhat),100*np.sum(yhat-y)/np.sum(y)])
            pred.extend([[s,yr,name,d,o,p] for d,o,p in zip(te.Date,y,yhat)])
metrics=pd.DataFrame(metrics,columns=["Station","Test_year","Model","Train_N","Test_N","NSE","KGE","RMSE","MAE","PBIAS_pct"])
pred=pd.DataFrame(pred,columns=["Station","Test_year","Model","Date","Observed","Predicted"])
metrics.to_csv(TAB/"ml_metrics.csv",index=False);pred.to_csv(TAB/"ml_predictions.csv",index=False)
# Compact journal figures
colors=dict(zip(stations,["#8E5EA2","#0072B2","#E69F00","#009E73"]))
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False})
fig,axs=plt.subplots(5,1,figsize=(11,12),sharex=True)
for ax,v in zip(axs,["Streamflow","TSS","NO3_NO2_N","PO4_P","P_total"]):
    for s,g in df.groupby("Station"):ax.plot(g.Date,g[v],color=colors[s],lw=1,label=s)
    ax.set_yscale("symlog",linthresh=1);ax.set_ylabel(v);ax.grid(alpha=.18)
axs[0].legend(ncol=4,frameon=False);fig.tight_layout();fig.savefig(FIG/"temporal_fingerprint.png",dpi=600,bbox_inches="tight");plt.close(fig)
piv=extreme.pivot(index="Station",columns="Constituent",values="Enrichment_factor").reindex(stations)
fig,ax=plt.subplots(figsize=(10,4.5));im=ax.imshow(piv,cmap="magma",aspect="auto")
ax.set_xticks(range(len(piv.columns)));ax.set_xticklabels(piv.columns,rotation=35,ha="right");ax.set_yticks(range(len(piv.index)));ax.set_yticklabels(piv.index)
for i in range(piv.shape[0]):
    for j in range(piv.shape[1]):ax.text(j,i,f"{piv.iloc[i,j]:.1f}x",ha="center",va="center",fontweight="bold",color="white")
fig.colorbar(im,ax=ax,label="Enrichment factor");fig.tight_layout();fig.savefig(FIG/"highflow_enrichment.png",dpi=600,bbox_inches="tight");plt.close(fig)
print("Analysis complete. Outputs written to results/generated_*. ")
